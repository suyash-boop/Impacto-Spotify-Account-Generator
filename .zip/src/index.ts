import { Zyphra } from "./cli/core/init";
Zyphra.xyz()

