import { META } from "../../../../constants";
import { Banner } from "../../../../ui/banner";

export function accountFollower() {
  new Banner({ x: "center", y: "top" }).setMeta(META)

  console.log("Hello");
}
